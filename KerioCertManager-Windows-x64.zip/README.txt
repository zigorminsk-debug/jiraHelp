Kerio SSL, Mail Deliverability & Blacklist Delist Center v3.0 (Windows x64)
===========================================================================

1. Скопируйте и запустите KerioCertManager.exe на сервере с Kerio Connect
   или на любом рабочем ПК администратора (Windows 10 / 11 / Windows Server 2016-2025).
2. Никаких .dll, OpenSSL, Certbot, Python или .NET устанавливать НЕ нужно — всё внутри одного файла.

Основные разделы v3.0:
1. Выпуск SSL Let's Encrypt (HTTP-01 на портах 80+443, TLS-ALPN-01, DNS-01 через VPN, IP-сертификаты и локальные самоподписанные до 10 лет).
2. Хранилище и выгрузка: PKCS#1 .key + fullchain.crt для Kerio Connect, .pfx, .zip.
3. Авто-установка сертификатов в Kerio Connect: локально в папку sslcert\ или удалённо по API :4040 (ConnectCertificate.*).
4. Проверка почты и Антиспам (v3.0 — 15+ глубоких проверок):
   - Автоопределение внешнего белого IP (через зашифрованный DNS-over-HTTPS + SPF + живой WAN IP) + автообход Split-DNS и Hairpin NAT.
   - MX/A, PTR/FCrDNS, SPF + глубина рекурсии 10 DNS-запросов RFC 7208, DKIM (mail._domainkey), DMARC.
   - Живая проверка SMTP 25, баннера HELO, защиты от Open Relay, служебных ящиков postmaster@/abuse@ и лимита SIZE.
   - Проверка 16 мировых спам-баз IP (RBL) + 4 доменных спам-баз (DBL/SURBL/URIBL).
   - Проверка кибербезопасности: открытые наружу опасные порты (RDP 3389 / Kerio Admin 4040 / SMB 445), устаревшие TLS 1.0/1.1, DNS CAA / MTA-STS / BIMI.
   - Инструмент живой отправки контрольного письма через ваш SMTP с полным логом сессии.
5. НОВАЯ ВКЛАДКА v3.0: «Выход из Блэклистов и Письма»:
   - Умный расшифровщик ошибок отлупа 550 / 554 из логов Kerio Connect.
   - Светофор готовности к разблокировке + готовое правило MikroTik для блокировки порта 25 у заражённых ПК офиса.
   - Готовые заполненные тексты писем и прямые ссылки на порталы разблокировки для Microsoft Outlook/Office 365 (S3150), Mail.ru, Google Gmail, Яндекс, Spamhaus, Barracuda, SpamCop/SORBS и интернет-провайдера (Белтелеком/A1/МТС).
