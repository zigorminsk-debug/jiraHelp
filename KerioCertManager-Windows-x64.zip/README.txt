Kerio SSL & Mail Server Manager v2.0 (Windows x64 Native GUI)
=============================================================

1. Скопируйте и запустите KerioCertManager.exe на сервере с Kerio Connect
   или на любом рабочем ПК администратора (Windows 10 / 11 / Windows Server 2016-2025).
2. Никаких .dll, OpenSSL, Certbot, Python или .NET устанавливать НЕ нужно — всё внутри одного файла.

Основные разделы v2.0:
- Выпуск SSL Let's Encrypt (HTTP-01 на портах 80+443, TLS-ALPN-01, DNS-01 через VPN, IP-сертификаты и локальные самоподписанные до 10 лет).
- Хранилище и выгрузка: PKCS#1 .key + fullchain.crt для Kerio Connect, .pfx, .zip.
- Авто-установка сертификатов в Kerio Connect: локально в папку sslcert\ или удалённо по API :4040 (ConnectCertificate.*).
- НОВОЕ в v2.0: Вкладка «Проверка почты и Антиспам» — полная живая диагностика MX, PTR (обратной зоны), SPF, DKIM (mail._domainkey), DMARC, портов 25/465/587/993/995/443, SSL/STARTTLS, баннера HELO, защиты от Open Relay и 11 мировых спам-баз (Spamhaus, Barracuda, SpamCop, SORBS) + готовая пошаговая инструкция по устранению проблем с кнопками копирования записей и экспортом HTML-отчёта.
